$(document).ready(function () {
    $('.color-control-btn').on("click", function () {
        $('.panel-box').toggleClass('controlbtnactive');
    });
    $('.red-color').click(function () {
        $('body').addClass('red-color-bar').css({
            "color": "red",
            "font-size": "24px"
        }).removeClass('green-color-bar').removeClass('yellow-color-bar').removeClass('violet-color-bar').removeClass('cyan-color-bar').removeClass('blue-color-bar')
    })
    $('.green-color').click(function () {
        $('body').addClass('green-color-bar').css({
            "color": "green",
            "font-size": "24px"
        }).removeClass('red-color-bar').removeClass('yellow-color-bar').removeClass('violet-color-bar').removeClass('cyan-color-bar').removeClass('blue-color-bar')
    })
    $('.yellow-color').click(function () {
        $('body').addClass('yellow-color-bar').css({
            "color": "yellow",
            "font-size": "24px"
        }).removeClass('green-color-bar').removeClass('red-color-bar').removeClass('violet-color-bar').removeClass('cyan-color-bar').removeClass('blue-color-bar')
    })
    $('.violet-color').click(function () {
        $('body').addClass('violet-color-bar').css({
            "color": "violet",
            "font-size": "24px"
        }).removeClass('red-color-bar').removeClass('yellow-color-bar').removeClass('green-color-bar').removeClass('cyan-color-bar').removeClass('blue-color-bar')
    })
    $('.cyan-color').click(function () {
        $('body').addClass('cyan-color-bar').css({
            "color": "cyan",
            "font-size": "24px"
        }).removeClass('green-color-bar').removeClass('red-color-bar').removeClass('yellow-color-bar').removeClass('violet-color-bar').removeClass('blue-color-bar')
    })
    $('.blue-color').click(function () {
        $('body').addClass('blue-color-bar').css({
            "color": "blue",
            "font-size": "24px"
        }).removeClass('red-color-bar').removeClass('green-color-bar').removeClass('yellow-color-bar').removeClass('cyan-color-bar').removeClass('violet-color-bar')
    });

    

    // skill bar
    $('#bar1').barfiller({

        // color of bar
        barColor: '#18d26e',

        // shows a tooltip
        tooltip: true,

        // duration in ms
        duration: 1000,

        // re-animate on resize
        animateOnResize: true,

        // custom symbol
        symbol: "%"

    });
    $('#bar2').barfiller({
        barColor: '#18d26e'
    });
    $('#bar3').barfiller({
        barColor: '#18d26e'
    });
    $('#bar4').barfiller({
        barColor: '#18d26e'
    });
    $('#bar5').barfiller({
        barColor: '#18d26e'
    });
    $('#bar6').barfiller({
        barColor: '#18d26e'
    });
    // Counterup
    $('.counter').counterUp({
        delay: 10,
        time: 1000
    });
    // Porfolio isotope and filter
    $(window).on('load', function () {
        var portfolioIsotope = $('.portfolio-container').isotope({
            itemSelector: '.portfolio-item',
            layoutMode: 'fitRows'
        });

        $('#portfolio-filters li').on('click', function () {
            $("#portfolio-filters li").removeClass('filter-active');
            $(this).addClass('filter-active');

            portfolioIsotope.isotope({
                filter: $(this).data('filter')
            });
            aos_init();
        });

        // Initiate venobox (lightbox feature used in portofilo)
        $(document).ready(function () {
            $('.venobox').venobox();
        });
    });
});